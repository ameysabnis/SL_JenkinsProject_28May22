package com.simplilearn.JenkinsProject_Scale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JenkinsProjectScaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
